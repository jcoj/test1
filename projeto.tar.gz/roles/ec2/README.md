Role Name
=========

Role to create EC2 Instances

variables:

image
ec2_instance_type

