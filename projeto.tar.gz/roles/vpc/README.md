Role Name
=========

VPC creation.

vpc_cidr_block: variable to set the VPC network.
