Role Name
=========
Subnet creation.

the_subnets: variable to set the subnets inside VPC.
