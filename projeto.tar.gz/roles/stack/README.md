Role Name
=========
Stacks , contains packages that will be installed.

variables

packages:
prerequisites_packages:

var directory contains an crypted file, secrets.yml 

